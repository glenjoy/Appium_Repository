package TestPageScenario;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import TestBase.DriverBase;
import TestPages.HomePage;
import general.KeywordFunctions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import TestPages.*;

public class HomePage_cartOperation extends DriverBase {
	protected Logger log = Logger.getLogger(HomePage.class.getName());// + ":" + nameofCurrMethod);
	public HomePage homepage = new HomePage();
	protected KeywordFunctions keys = new KeywordFunctions(driver);

	public Properties obj;
	public FileInputStream objfile;
	public String name_, mobile_, pincode_, address_;
	WebDriverWait wait;

	public HomePage_cartOperation(AppiumDriver driver) {
		// TODO Auto-generated constructor stub

		PageFactory.initElements(new AppiumFieldDecorator(driver), homepage);
	}

	// performing cart operation after login
	public void cartoperation() throws InterruptedException, IOException {
		wait = new WebDriverWait(driver, 10);
		obj = new Properties();
		log.info(getClass());
		System.out.println(System.getProperty("user.dir"));
		objfile = new FileInputStream(System.getProperty("user.dir") + "/util/testdata.properties");
		obj.load(objfile);
		/*
		 * To read data from excel sheet ExcelRead=new
		 * FileInputStream("TestData/testdata.xlsx"); wbk=new XSSFWorkbook(ExcelRead);
		 * String search_item = wbk.getSheetAt(0).getRow(3).getCell(1).toString();
		 */
		log.info("Login successfull");
		name_ = obj.getProperty("name");
		log.info("Reading name from external property file");
		mobile_ = obj.getProperty("mobile");
		log.info("Reading mobile number from external property file");
		pincode_ = obj.getProperty("pincode");
		log.info("Reading pincode from external property file");
		address_ = obj.getProperty("address");
		log.info("Reading address from external property file");
		
		System.out.println("Full Name : " + name_);
		System.out.println("PinCode : " + pincode_);
		System.out.println("Mobile Number : " + mobile_);
		System.out.println("Address : " + address_);

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.start_shopping)));
		log.info("Clicked on Start Shopping successfully");

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.menu_button)));
		log.info("Clicked on Menu button successfully");

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.menu_girls)));
		log.info("Clicked on Girls under Menu options");

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.girls_shoes)));
		log.info("Clicked on Shoes under Girls Menu");
		
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.shoes_name)));
		log.info("Clicked on the Shoes");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.shoes_size)));
		log.info("Selected the shoes size");

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.add_basket)));
		log.info("Clicked on Add to Basket");

		if(wait.until(ExpectedConditions.visibilityOf(homepage.text_successfullyadded)).isDisplayed())
		{
			boolean status =homepage.text_successfullyadded.isDisplayed();
			System.out.println(status);
			log.info("Added to basket Successfully");
		}

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.checkout)));
		log.info("Clicked on checkout");
		
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.checkout_now)));
		log.info("Clicked on Checkout now successfully");

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.home_delivery)));
		log.info("Clicked on home delivery");
		
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.full_name)));
		log.info("Clicked on Full Name");
		
		keys.sendSetText(wait.until(ExpectedConditions.visibilityOf(homepage.full_name)), name_);
		log.info("Entered Full Name");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		keys.enter_key();
		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.mob_num)));
		log.info("Clicked on Mobile Number");
		
		keys.sendSetText(wait.until(ExpectedConditions.visibilityOf(homepage.mob_num)), mobile_);
		log.info("Entered Mobile Number");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		keys.enter_key();

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.address)));
		log.info("Clicked on Address");
		
		keys.sendSetText(wait.until(ExpectedConditions.visibilityOf(homepage.address)),address_);
		log.info("Entered Address");
		keys.enter_key();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.pin_code)));
		log.info("Clicked on PinCode");
				
		keys.sendSetText(wait.until(ExpectedConditions.visibilityOf(homepage.pin_code)),pincode_);
		log.info("Entered Pin Code");
		keys.enter_key();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		keys.clickElement(wait.until(ExpectedConditions.visibilityOf(homepage.proceed_payment)));
		log.info("Clicked on Proceed to Payment successfully");

		
		

	}

}
