package TestPages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.temporal.ChronoUnit;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import TestBase.DriverBase;
import general.KeywordFunctions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.WithTimeout;
import org.testng.Assert;

public class HomePage extends DriverBase {

	// page factory design
	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[@resource-id='com.applications.lifestyle:id/startShoppingBtn']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement start_shopping;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.ImageView[@resource-id='com.applications.lifestyle:id/actionbar_drawer_icon']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement menu_button;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.applications.lifestyle:id/text_item_search']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement home_search_box;

	@CacheLookup
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.drawerlayout.widget.DrawerLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ExpandableListView/android.widget.LinearLayout[8]")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement menu_girls;

	@CacheLookup
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.drawerlayout.widget.DrawerLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.FrameLayout/androidx.recyclerview.widget.RecyclerView/android.widget.RelativeLayout[6]")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement girls_shoes;

	
	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='FAME FOREVER Mid-Top Casual Shoes with Embellished Velcro']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement shoes_name;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.RadioButton[@text='32']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement shoes_size;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.LinearLayout[@resource-id='com.applications.lifestyle:id/addToBasket']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement add_basket;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Successfully added to your basket']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement text_successfullyadded;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[@resource-id='com.applications.lifestyle:id/continueShoppingBtn']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement continue_shopping;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[@resource-id='com.applications.lifestyle:id/checkoutNowBtn']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement checkout;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.applications.lifestyle:id/checkoutNow']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement checkout_now;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.RadioButton[@resource-id='com.applications.lifestyle:id/radio_button_home_delivery']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement home_delivery;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.applications.lifestyle:id/input_full_name']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement full_name;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.applications.lifestyle:id/input_mobile_number']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement mob_num;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.applications.lifestyle:id/input_pincode']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement pin_code;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.applications.lifestyle:id/input_address']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement address;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.applications.lifestyle:id/button_proceed_to_payment']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement proceed_payment;

	
	// page factory initialization
	/*
	 * public HomePage() {
	 * PageFactory.initElements(new AppiumFieldDecorator(driver), this); }
	 */
}

