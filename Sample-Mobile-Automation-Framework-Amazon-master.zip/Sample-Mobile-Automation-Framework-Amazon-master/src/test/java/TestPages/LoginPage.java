package TestPages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.temporal.ChronoUnit;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import TestBase.DriverBase;
import general.KeywordFunctions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.WithTimeout;
import io.appium.java_client.pagefactory.iOSFindBy;

public class LoginPage extends DriverBase {

	// page factory design
	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.RelativeLayout[@resource-id='com.applications.lifestyle:id/startShoppingBtn']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement start_shopping;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.ImageView[@resource-id='com.applications.lifestyle:id/actionbar_drawer_icon']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement menu_button;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.ImageView[@resource-id='com.applications.lifestyle:id/loggedin_image']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement sign_in_menu;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.applications.lifestyle:id/email_id_login']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement email_id;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.EditText[@resource-id='com.applications.lifestyle:id/password_text']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement password;

	@CacheLookup
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id='com.applications.lifestyle:id/btn_signin']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement sign_in;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Please enter a valid username and password']")
	@WithTimeout(time = 25, chronoUnit = ChronoUnit.SECONDS)
	public WebElement invalidpassword_text;
	
	





	// page factory implementation
	/*
	 * public LoginPage() { 
	 * PageFactory.initElements(new AppiumFieldDecorator(driver), this); }
	 */

}
